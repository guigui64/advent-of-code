export default () => (
  <div class="container" style={{position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)'}}>
    <h1 class="text-center">Nope</h1>
    <p class="text-center">Sorry, not yet implemented... Come back later !</p>
  </div>
);
