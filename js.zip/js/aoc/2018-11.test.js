const { all } = require('./2018-11');

// Example
//console.log(all('18'));
//console.log(all('42'));

// Real input
input=`9435`;

console.log(all(input));
